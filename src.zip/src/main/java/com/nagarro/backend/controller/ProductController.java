package com.nagarro.backend.controller;

import java.io.Console;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.backend.entity.Product;
import com.nagarro.backend.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {

	@Autowired
	private ProductService service;

	/*
	 * 
	 * This API is used to accept the request from client side and store product
	 * 
	 * @Param Product
	 * 
	 * @Return nothing
	 */
	@PostMapping("/insertProduct")
	public void insertProduct(@RequestBody Product product) throws Exception {
		System.out.println(product.toString());
		String subject = product.getSubject();
		Product productObj = service.getProduct(subject);

		if (productObj != null) {
			throw new Exception("This productCode is already present please check on product page");
		} else {
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date date = new Date();
			product.setDate(dateFormat.format(date));
			service.saveProduct(product);
		}
	}

	/*
	 * This API is used to get the product with help of productId
	 * 
	 * @Param productId
	 * 
	 * @Return Product
	 */
	@GetMapping("/getProductById/{id}")
	public Product getProductById(@PathVariable("id") String subject) throws Exception {
		try {
			System.out.print("insdide if");
			System.out.println(this.service.getProduct(subject));
			return this.service.getProduct(subject);
		} catch (Exception e) {
			throw new Exception("FETCHING_FAILED");
		}
	}

	@GetMapping("/getAllQuestions/{userName}")
	public List<Product> getAllQuestions(@PathVariable("userName") String userName) {
		return service.getAllQuestions(userName);
	}

	/*
	 * This API is used to get the product list with help of productSearch
	 * 
	 * @Param productSearch
	 * 
	 * @Return List<Product>
	 */
	@GetMapping("/getProductBySearch/{productSearch}")
	public List<Product> getProductListBySearch(@PathVariable("productSearch") String productSearch) throws Exception {
		productSearch = productSearch.replaceAll(" ", "");
		System.out.println(productSearch);
		List<Product> productList;
		try {
			productList = service.getProductListBySearch(productSearch);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		System.out.println(productSearch);
		System.out.println(productList);
		return productList;
	}
}
