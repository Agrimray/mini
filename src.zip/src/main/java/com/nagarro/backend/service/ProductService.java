package com.nagarro.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.nagarro.backend.entity.Product;
import com.nagarro.backend.repository.ProductRepository;


@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;

	public Product saveProduct(Product product) {
		Product productObj = productRepository.save(product);
		return productObj;
	}

	public Product getProduct(String subject) {

		Product productObj = productRepository.findBySubject(subject);
		
		return productObj;
	}

	public void updateProductReview(Product product) {
		productRepository.save(product);
	}
	public List<Product>getAllQuestions(String userName){
		
		return productRepository.findByUserName(userName);
		
	}
	public List<Product> getProductListBySearch(String search)
	{
		return productRepository.findBySearch(search);
	}

	/*public Long countAllProduct() {
		return repo.count();}*/
	}
