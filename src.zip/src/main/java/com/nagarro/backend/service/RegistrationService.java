package com.nagarro.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nagarro.backend.repository.RegistrationRepository;
import com.nagarro.backend.entity.User;

@Service
public class RegistrationService {
	@Autowired
	private RegistrationRepository repository;
	
	

	public User saveUser(User user) {
		return repository.save(user);
	}

	// This method is used to get User with help of user emailId

	public User fetchUserByEmailId(String emailId) {
		return repository.findByEmailId(emailId);
	}

	// This method is used to get count of all Registrated User

	public Long countAllRegistrated() {
		return repository.count();
	}

}
